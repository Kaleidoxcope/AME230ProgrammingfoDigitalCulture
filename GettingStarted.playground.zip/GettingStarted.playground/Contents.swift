import Cocoa

var str = "Hello, playground"

// A few temperature values

var temperature1 = 80.2
var temperature2 = 85.7
var temperature3 = 92.5
var averageTemperature = (temperature1 + temperature2 + temperature3)/3
